void main(){
    return k;
}
